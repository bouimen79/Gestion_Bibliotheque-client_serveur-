package serveu;

//serveur
import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author LMO
 */
public class Thread_principale extends Thread {

    //Thread_reception Thread_Recept;
    ServerSocket Server_Sock;
    Socket sock;
    InputStream Flux_Entree;
    int indice = 0;
    OutputStream Flux_Sortie;
    BufferedReader Reader;
    PrintWriter Writer;
    Fen_princi Fen_pr;
    ArrayList<PrintWriter> W = new ArrayList<PrintWriter>();
    ArrayList<BufferedReader> R = new ArrayList<BufferedReader>();
   // ArrayList<Thread_reception> T = new ArrayList<Thread_reception>();

    public Thread_principale(Fen_princi Fen_principale_p) {
        Fen_pr = Fen_principale_p;
    }
    public void run() {
        try {
            Attendre_Demande_connexion();
        } catch (Exception e) {
        }
    }
    void Attendre_Demande_connexion() {
        try {

            Server_Sock = new ServerSocket(1000);
            while (true) {
                System.out.println("en attente des demandes de connexion.........");
               
                sock = Server_Sock.accept();
                System.out.println("demande de connexion accepter");
                //______________________________________________________________________
                System.out.println("recuperation des flux de entrer et de sortie");
                Flux_Entree = sock.getInputStream();
                Reader = new BufferedReader(new InputStreamReader(Flux_Entree));
//------------------- -----**la liste des reader qui accept plusieur client** -------------------------------------------//
                R.add(Reader);
                Flux_Sortie = sock.getOutputStream();
                Writer = new PrintWriter(Flux_Sortie, true);
             // System.out.println("Writer==" + Writer);
                Writer.println(indice + "");
 //-----------------------indice du client-------------------------------------------------------------------------------//               
                indice++;
 //---------------la liste des writer qui envoie au plusieur client-----------------------------------------------------//
                W.add(Writer);
                System.out.println("Flux d'entree et de sortie recuperer");
                //Recuperer_les_flux();
                Thread_reception Thread_Recept = new Thread_reception(Fen_pr, this);
                Thread_Recept.Reader1 = Reader;
                Thread_Recept.start();
                Dialoguer();
            }

        } catch (Exception e) {
            System.out.println("erreur dans l'acceptation de la demande de connexion");

        };
    }

    void Dialoguer() {
        Thread_reception Thread_Recept = new Thread_reception(Fen_pr, this);
        Thread_Recept.start();
    }

    void Fermer_connexion() {
        try {
            Flux_Entree.close();
            Flux_Sortie.close();
            sock.close();
            System.out.println("connexion fermer");
        } catch (Exception e) {
            System.out.println("erreur");
        };
    }
}
