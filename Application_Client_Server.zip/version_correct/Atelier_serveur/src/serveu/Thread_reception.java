package serveu;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;
import javax.swing.table.DefaultTableModel;
import serveu.Thread_principale;

public class Thread_reception extends Thread {

    Fen_princi Fen_pr;
    BufferedReader Reader1;
    Thread_principale Thread_pr;
    Connection conx;
    PreparedStatement pst, pst1;
    ResultSet res, res1;
    Statement st, st1;

    public Thread_reception(Fen_princi Fen_principale_p, Thread_principale Thread_principale_p) {
        Fen_pr = Fen_principale_p;
        Thread_pr = Thread_principale_p;

    }

    public String calcul_date(int jour) {
        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = new GregorianCalendar();
      
        String date_empr = s.format(c.getTime());
        c.add(Calendar.DAY_OF_MONTH, jour);
        String date_ret = s.format(c.getTime());
        return date_empr + "," + date_ret;
    }

    public String calcul_difference_date(String id_empr, String ret_date_ret) {
        String etat = null;
        try {
            String t_emprunt = "select date_retour from emprunte where id_emprunteur=" + id_empr;
            String t_retoun = "select date_ret from retourner where id_emprunteur=" + id_empr;
            st = conx.createStatement();
            st1 = conx.createStatement();
            res = st.executeQuery(t_emprunt);
            res1 = st1.executeQuery(t_retoun);
            String emp_date_ret = null;
            while (res.next()) {
                emp_date_ret = res.getString("date_retour");
                //                  System.out.println("date_retour de table empret :="+emp_date_ret);                   
            }
            while (res1.next()) {
                ret_date_ret = res1.getString("date_ret");
//                    System.out.println("\n date_retourne de la table de retour"+ret_date_ret);
            }
            SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
            Date d1 = s.parse(emp_date_ret);
            Date d2 = s.parse(ret_date_ret);
            long difference_In_Time = d2.getTime() - d1.getTime();
            long compare_jour = TimeUnit.MILLISECONDS.toDays(difference_In_Time) % 365;
            System.out.println("\n les jour de retard : " + compare_jour);

            if (compare_jour == 0) {
                etat = "normal";
                System.out.println("awradit laktab falwact \n");
            } else {
                if (compare_jour<0) {
                    etat = "normal";
                    System.out.println("walo");
                } else {
                    etat = "En Retard";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return etat;
    }

    public void connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:C:\\Users\\imen\\Downloads\\version_correct\\Atelier_serveur\\serveur.db";
            conx = DriverManager.getConnection(url);
           
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e);
        }
    }

    public void run() {
//---------------------------------/*la connexion sur la base de donnée*/--------------------------------------------//

        connect();
        while (true) {
            try {
//---------------------------/*message recu par le client */---------------------------//
                String Message_Recu = Reader1.readLine();
                String s1[] = Message_Recu.split(",");
                String indice = s1[0];//------/*indice de client*/-----------//
                String ordre = s1[1];//------------/*ordre qui veut le client*/-----//
                int i = Integer.parseInt(indice);
                Fen_pr.client3.append("Le client Numero : " + i + " A bien connecter " + '\n');
                switch (ordre) {
                    case "connexion": {
                        String nom_utilisateur = s1[2];
                        String mot_de_passe = s1[3];                       
                        try {
//------------/*rechercher sur la base de donne 3la lnom_utilisateur et le mot_de pass s'ils existent*/---------------//
                            String requete = "SELECT * FROM compte where nom_utilisateur=? and mot_de_pass=?;";
                            pst = conx.prepareStatement(requete);
                            pst.setString(1, nom_utilisateur);
                            pst.setString(2, mot_de_passe);
                            res = pst.executeQuery();
                            if (res.next()) {
                                Thread_pr.W.get(i).println("bien connecter");
                                pst.close();
                                res.close();
                            } else {
                                Thread_pr.W.get(i).println("Erreur");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            System.out.println("Erreur" + e);
                        }
                        try {
                            String select_donne = "select type,id_document,code_isbn,titre from document_1";
                            st = conx.createStatement();
                            res = st.executeQuery(select_donne);
                            String Type = null, Id_document = null, code_ISBN = null, Titre = null;
                            while (res.next()) {
                                Type = res.getString("type");
                                Id_document = res.getString("id_document");
                                code_ISBN = res.getString("code_isbn");
                                Titre = res.getString("titre");
                                Thread_pr.W.get(i).println("donne" + "," + Type + "," + Id_document + "," + code_ISBN + "," + Titre);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    case "inscri": {
                        String nom = s1[2];
                        String prenom = s1[3];
                        String nom_utilisateur = s1[4];
                        String mot_de_passe = s1[5];
                      
                        try {
                            String insert = "INSERT INTO compte( nom , nom_utilisateur, mot_de_pass, prenom)VALUES(?,?,?,?)";
                            pst1 = conx.prepareStatement(insert);
                            try {
                                pst1.setString(1, nom);
                                pst1.setString(2, nom_utilisateur);
                                pst1.setString(3, mot_de_passe);
                                pst1.setString(4, prenom);
                                pst1.execute();
                                Thread_pr.W.get(i).println("bien inscrit");
                            } catch (Exception e) {
                                Thread_pr.W.get(i).println("nom_utilisateur existé");
                            }

                        } catch (Exception e) {

                        }
                        break;
                    }
                    case "oublier": {
                        String Nom = s1[2];
                        String id_utilisateur = "'" + s1[3] + "'";
                        String nv_mot_de_passe = "'" + s1[4] + "'";
                        try {
                            //-----------------/* si le client oublier le mot de pass il peut le modifier facilement */-------------------------------------//                           
                            String sql = "UPDATE compte set mot_de_pass = " + nv_mot_de_passe + " WHERE nom_utilisateur=" + id_utilisateur;
                            st = conx.createStatement();
                            st.executeUpdate(sql);
                            Thread_pr.W.get(i).println("mot de passe modifier");
                         
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }

                    case "nv_emprunteur": {
                        String id = s1[2];
                        String nom = s1[3];
                        String prenom = s1[4];
                        String date = s1[5];
                        try {
                            String insert = "INSERT INTO nv_emprunteur(id_emprunteur,nom,prenom,date_naissance)Values(?,?,?,?)";
                            pst = conx.prepareStatement(insert);
                            pst.setString(1, id);
                            pst.setString(2, nom);
                            pst.setString(3, prenom);
                            pst.setString(4, date);
                            pst.execute();
                            Thread_pr.W.get(i).println("Bien inscri nv_emprunteur");

                        } catch (Exception e) {
                            Thread_pr.W.get(i).println("Erreur d'inscription");
                        }
                        break;
                    }
//------------------------------------------------------------------------------
                     case "information": {
                        String code_isbn = s1[2];
                        String id_empr = s1[3];
                        
                        String select = "SELECT * From nv_emprunteur WHERE id_emprunteur=" + id_empr;
                        try {
                            st = conx.createStatement();
                            res = st.executeQuery(select);
                            String nom = null;
                            String prenom = null;
                            String titre = null;
                            String anne = null;
                            String editeur = null;
                            String reference = null;
                            String auteur = null;
                            String id_docu = null;
                            String type = null;
                            while (res.next()) {
                                nom = res.getString("nom");
                                prenom = res.getString("prenom");
                                String date = res.getString("date_naissance");
                                String text_envoyer = "information emprunteur" + "," + nom + "," + prenom + "," + date;
                                Thread_pr.W.get(i).println(text_envoyer);
                            }
                            String sql = "SELECT * FROM document_1 WHERE code_isbn=" + code_isbn;

                            st = conx.createStatement();
                            res = st.executeQuery(sql);
                            while (res.next()) {
                                id_docu = res.getString("id_document");
                                titre = res.getString("titre");
                                anne = res.getString("anne");
                                editeur = res.getString("editeur");
                                reference = res.getString("reference");
                                auteur = res.getString("auteur");
                                type = res.getString("type");
                                Thread_pr.W.get(i).println("information document" + "," + titre + "," + anne + "," + editeur + "," + reference + "," + auteur + "," + type + "," + id_docu);
                            }
                       
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
//---------------------------------------------------------------------------------------------------------------------------
                    case "emprunt": {
                        String id_exemplaire = s1[2];
                       
                        String id_empr = s1[3];
                        String date_empr = s1[4];
                        String date_ret = s1[5];
                  
//---------------------------------------------------------------------------insert into emprunt-------------------------------//
                        try {
                            String insert_emp = "insert into emprunte(id_exemplaire,id_emprunteur,date_emprunt,date_retour)values(?,?,?,?)";
                            pst1 = conx.prepareStatement(insert_emp);
                            pst1.setString(1, id_exemplaire);
                            pst1.setString(2, id_empr);
                            pst1.setString(3, date_empr);
                            pst1.setString(4, date_ret);
                            pst1.execute();
                            pst1.close();
//--------------------------------------------------------------------------update etat de document-----------------//

                            String update = "UPDATE exemplaire set situ ='En prete' WHERE id_exemplaire=" + id_exemplaire;
                            st = conx.createStatement();
                            st.executeUpdate(update);
                            st.close();
//----------------------------------------------------------------Insert Into emprunteur--------------------------//
                            String insert = "INSERT INTO emprunteur(id_emprunteur,date_emprunt)VALUES(?,?)";
                            pst = conx.prepareStatement(insert);
                            pst.setString(1, id_empr);
                            pst.setString(2, date_empr);
                            pst.execute();
                            pst.close();
                            String table[] = {id_exemplaire, id_empr, date_empr, date_ret};
                            DefaultTableModel tb = (DefaultTableModel) Fen_princi.Tab_emp4.getModel();
                            tb.addRow(table);
                            Thread_pr.W.get(i).println("bien emprunter");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
//-------------------------------------rechercher etat d'emprunteur-------------------------------------------------------------------------------
                    case "chercher etat d'emprunteur": {
                        String id_empr = s1[2];
                        String sql1 = "select count(*)from emprunteur where id_emprunteur=" + id_empr;
                        st = conx.createStatement();
                        res = st.executeQuery(sql1);
                        int nombre = res.getInt(1);
                        st.close();
                        String etat_client = null;
                        String sele = "select count(*)from emprunte where id_emprunteur=" + id_empr;

                        st1 = conx.createStatement();
                        res = st1.executeQuery(sele);
                        int n = res.getInt(1);
                        st1.close();
                        if (nombre <= 4) {
                            etat_client = "client occasionel";
                            String date = calcul_date(15);
                            String s[] = date.split(",");
                            String date_emp = s[0], date_retour = s[1];
                            String text_envoyer = "Etat de client" + "," + etat_client + "," + date_emp + "," + date_retour;
                            if (n == 1) {
                                Thread_pr.W.get(i).println("Erreur d'emprunt");
                            } else {
                                Thread_pr.W.get(i).println(text_envoyer);
                            }
                            break;
                        }
                        if (nombre > 4) {
                            etat_client = "client abonnées";
                            String date = calcul_date(30);
                            String s[] = date.split(",");
                            String date_emp = s[0], date_retour = s[1];
                            String text_envoyer = "Etat de client" + "," + etat_client + "," + date_emp + "," + date_retour;
                            if (n == 4) {
                                Thread_pr.W.get(i).println("Erreur d'emprunt");
                            } else {
                                Thread_pr.W.get(i).println(text_envoyer);
                            }
                            break;
                        }
                        if (nombre >= 8) {
                            etat_client = "client priviligié";
                            String date = calcul_date(30);
                            String s[] = date.split(",");
                            String date_emp = s[0], date_retour = s[1];
                            String text_envoyer = "Etat de client" + "," + etat_client + "," + date_emp + "," + date_retour;
                            if (n == 8) {
                                Thread_pr.W.get(i).println("Erreur d'emprunt");
                            } else {
                                Thread_pr.W.get(i).println(text_envoyer);
                            }
                            break;
                        }
                       
                        break;
                    }
             //-------------------------------------------------------/*rechercher  un document------------------------------------------------//   
                   
                       
                      case "chercher document": {
                        String code = s1[2];
                        try {
                            String select = "Select situ,id_exemplaire From exemplaire WHERE code_isbn=" + code;
                            st = conx.createStatement();
                            res = st.executeQuery(select);
                            ArrayList<String> situation = new ArrayList<String>();
                            ArrayList<String> id_exp = new ArrayList<String>();
                            String id_exemplaire = null;
                            while (res.next()) {
                                String etat = res.getString("situ");
                                String id_exemp = res.getString("id_exemplaire");
                                System.out.println("la situation" + etat + "son id est " + id_exemp);
                                situation.add(etat);
                                id_exp.add(id_exemp);
                            }

                            int cmpt_rayon = 0;
                            for (int j = 0; j < situation.size(); j++) {
                                if (situation.get(j).equals("En Rayon")) {
                                    id_exemplaire = id_exp.get(j);
                                    //   System.out.println("\n il y'a un exemplaire en rayon son id est +"+id+"\n");
                                    cmpt_rayon++;
                                } else {
                                    //  System.out.println("tous les exemplaire en reserve");
                                }
                            }
                            if (cmpt_rayon > 0) {
                                //  System.out.println("vous pouver emprunter ce document son id est="+id);
                                Thread_pr.W.get(i).println("Etat" + "," + "En Rayon" + "," + id_exemplaire);
                            } else {
                                // System.out.println("vous ne pouver pas emprunter ce document ");
                                Thread_pr.W.get(i).println("Etat" + "," + "En Réserve");
                            }
                            //    System.out.println("la liste des situation est +"+situation);
                            //   System.out.println("\nla liste des id_exemp est +"+id_exp);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    case "retourner": {
                        String id_empr = s1[2];
                        String id_exemplaire = s1[3];
                        String etat = s1[4];
                        String etat_exemplaire_avant = null;
                        System.out.println(etat);
                        String date = s1[5];
                        try {
                            String select_etat = "select etat from exemplaire where id_exemplaire=" + id_exemplaire;
                            st1 = conx.createStatement();
                            res1 = st1.executeQuery(select_etat);
                            while (res1.next()) {
                                etat_exemplaire_avant = res1.getString("etat");
                                System.out.println("etat d'exemplaire" + etat_exemplaire_avant);
                            }
                            try {
                                if ((etat_exemplaire_avant.equals("neuf") && etat.equals("bon état")) || (etat_exemplaire_avant.equals("trés bon état") && etat.equals("endommagé")) || (etat_exemplaire_avant.equals("bon état") && etat.equals("usagé")) || (etat_exemplaire_avant.equals("neuf") && etat.equals("endommagé")) || (etat_exemplaire_avant.equals("neuf") && etat.equals("usagé")) || (etat_exemplaire_avant.equals("trés bon état") && etat.equals("endommagé")) || (etat_exemplaire_avant.equals("trés bon état") && etat.equals("usagé"))|| (etat_exemplaire_avant.equals("usagé") && etat.equals("endommagé"))) {
                                    System.out.println("kayna ghrama \n");
                                    Thread_pr.W.get(i).println("ghrama");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            String insert = "insert into retourner(id_emprunteur,id_exemplaire,etat,date_ret)values(?,?,?,?)";
                            pst = conx.prepareStatement(insert);
                            pst.setString(1, id_empr);
                            pst.setString(2, id_exemplaire);
                            pst.setString(3, etat);
                            pst.setString(4, date);
                            pst.execute();
                            pst.close();
                            String etat_retour_document = calcul_difference_date(id_empr, date);
                            try {
                                String delete = "delete from emprunte where id_emprunteur='" + id_empr + "'and id_exemplaire='" + id_exemplaire + "';";
                                st = conx.createStatement();
                                st.executeUpdate(delete);
                                st.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }  ;

                            if (etat_retour_document.equals("En Retard")) {
                                System.out.println("en retard");
                                Thread_pr.W.get(i).println("bien Retourner le document" + "," + etat_retour_document);
                            } else {
                                if (etat_retour_document.equals("normal")) {
                                    System.out.println("bien retourner");
                                }

                                Thread_pr.W.get(i).println("bien Retourner le document" + "," + etat_retour_document);

                            }
                         

                            switch (etat) {
                                case "neuf": {
                                    String updat = "update exemplaire set situ='En Rayon',etat='neuf' where id_exemplaire= " + id_exemplaire;
                                    st = conx.createStatement();
                                    st.executeUpdate(updat);
                                    st.close();
                                    break;
                                }
                                case "trés bon état": {
                                    String updat = "update exemplaire set situ='En Rayon',etat='trés bon état' where id_exemplaire= " + id_exemplaire;
                                    st = conx.createStatement();
                                    st.executeUpdate(updat);
                                    st.close();
                                    break;
                                }
                                case "bon état": {
                                    String updat = "update exemplaire set situ='En Rayon',etat='bon état' where id_exemplaire= " + id_exemplaire;
                                    st = conx.createStatement();
                                    st.executeUpdate(updat);
                                    st.close();
                                    break;
                                }
                                case "endommagé": {
                                    String updat = "update exemplaire set situ='En travaux',etat='endommagé' where id_exemplaire= " + id_exemplaire;
                                    st = conx.createStatement();
                                    st.executeUpdate(updat);
                                    st.close();
                                    break;
                                }
                                case "usagé": {
                                    String delete = "delete from exemplaire where id_exemplaire=" + id_exemplaire;
                                    st = conx.createStatement();

                                    int a = st.executeUpdate(delete);
                                    if (a > 0) {
                                        System.out.println("bien supprimer");
                                    }
                                    String table[] = {id_exemplaire, id_empr, etat, date};
                                    DefaultTableModel tb = (DefaultTableModel) Fen_princi.Tab_ret3.getModel();
                                    tb.addRow(table);

                                    st.close();
                                    break;
                                }
                                default:
                                    System.out.println("Erreur dans switch des etat en rtourner");
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    default:
                        System.out.println("Erreur dans switch");

                }

            } catch (Exception e) {

            }

        }
    }
}
