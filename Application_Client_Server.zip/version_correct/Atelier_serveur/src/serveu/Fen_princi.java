/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serveu;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author imen
 */
public class Fen_princi extends javax.swing.JFrame {

    Connection conx;
    Statement st, st1;
    ResultSet res, res1;
    PreparedStatement pst;
    Thread_principale Thread_pr;

    public Fen_princi() {
        initComponents();
        setSize(650, 420);
        setLocation(600, 100);
        jPanel9.setBackground(new Color(0, 0, 0, 10));
        jPanel3.setBackground(new Color(0, 0, 0, 0));
        jPanel4.setBackground(new Color(0, 0, 0, 0));
        jPanel5.setBackground(new Color(0, 0, 0, 0));
        jPanel8.setBackground(new Color(0, 0, 0, 10));
        page_connex.setSize(585, 550);
        page_connex.setLocation(600, 100);
        page_connex_s.setSize(585, 550);
        page_connex_s.setLocation(600, 100);
        page_exemplaire.setSize(552, 824);
        page_exemplaire.setLocation(600, 100);
        page_Home_admin1.setSize(1128, 850);
        page_Home_admin1.setLocation(100, 50);
        nouveu_doc.setSize(552, 850);
        nouveu_doc.setLocation(600, 50);

        jButton11.setBackground(Color.WHITE);
        jButton9.setBackground(Color.WHITE);

        connect();
        chercher_En_retard();
        afficher_list_emprunt_et_retour();

    }

    public void connect() {
        try {
//---------------------------------/*la connexion sur la base de donnée--------------------------------------------//
            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:C:\\Users\\imen\\Downloads\\version_correct\\Atelier_serveur\\serveur.db";
            conx = DriverManager.getConnection(url);
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e);
        }
    }
void chercher_En_retard(){
    SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
    Calendar c = new GregorianCalendar();
   try{
   String   date_jour=s.format(c.getTime());
   System.out.println("date_d'aujourduit :"+date_jour+"\n"); 
   String sql="select id_emprunteur,date_retour from emprunte ";
   st=conx.createStatement();
   res=st.executeQuery(sql);
   String date_ret = null,id=null;
   ArrayList<String> dat=new ArrayList<String>();
   while(res.next()){
       date_ret=res.getString("date_retour");
       id=res.getString("id_emprunteur");
       System.out.println("date_retour de la table d'emprunte"+res.getString("date_retour")+","+"id_emprunteur"+id);
       dat.add(date_ret);      
   }
        Date d1=s.parse(date_jour);
            long difference_In_Days = 0 ;
   for(int i=0;i<dat.size();i++){
      System.out.println("dat"+dat.get(i));
       String dat_ret=dat.get(i);
        Date d2=s.parse(date_ret);
        long difference_In_Time  = d1.getTime() - d2.getTime();
         difference_In_Days  = TimeUnit .MILLISECONDS .toDays(difference_In_Time)  % 365;         
    }
    System.out.println("\ndifference ="+difference_In_Days);
          if(difference_In_Days==0){
            System.out.println("kalach riglo"); 
        }else{
            if(difference_In_Days<0){
                System.out.println("walo");
            }else
        javax.swing.JOptionPane.showMessageDialog(null, "il ya un emprunteur en retard?!"+"leur id est:"+id, "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
   }catch(Exception e){
     e.printStackTrace();
   }
    }
    void afficher_list_emprunt_et_retour() {
        try {
            // TODO add your handling code here:
            String sql = "select * from emprunte";
            st = conx.createStatement();
            res = st.executeQuery(sql);
            while (res.next()) {
                String id_do = res.getString("id_exemplaire");
                String id_emp = res.getString("id_emprunteur");
                String date_emp = res.getString("date_emprunt");
                String date_ret = res.getString("date_retour");
                String table[] = {id_do, id_emp, date_emp, date_ret};

                DefaultTableModel tb = (DefaultTableModel) Tab_emp4.getModel();
                tb.addRow(table);

            }
            String sql1 = "select *from retourner";
            st1 = conx.createStatement();
            res1 = st1.executeQuery(sql1);
            while (res1.next()) {
                String id_do = res1.getString("id_exemplaire");
                String id_emp = res1.getString("id_emprunteur");
                String etat = res1.getString("etat");
                String date_ret = res1.getString("date_ret");
                String table[] = {id_do, id_emp, etat, date_ret};
                DefaultTableModel tb = (DefaultTableModel) Tab_ret3.getModel();
                tb.addRow(table);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void Lancer_Thread_Principale() {
        Thread_pr = new Thread_principale(this);
        Thread_pr.start();
    }

    void ferme() {
        Thread_pr.Fermer_connexion();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        page_connex = new javax.swing.JFrame();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        mt_pass = new javax.swing.JPasswordField();
        nom_util = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        page_connex_s = new javax.swing.JFrame();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        mt_pass1 = new javax.swing.JPasswordField();
        nom_util1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        page_exemplaire = new javax.swing.JFrame();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField2 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        id_document_exemp = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        date_achat = new javax.swing.JTextField();
        date = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        page_Home_admin1 = new javax.swing.JFrame();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        client3 = new javax.swing.JTextArea();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        Tab_ret3 = new javax.swing.JTable();
        jLabel35 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        Tab_emp4 = new javax.swing.JTable();
        jLabel36 = new javax.swing.JLabel();
        jToolBar3 = new javax.swing.JToolBar();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        nouveu_doc = new javax.swing.JFrame();
        jPanel8 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        titre = new javax.swing.JTextField();
        anne = new javax.swing.JTextField();
        editeur = new javax.swing.JTextField();
        reference = new javax.swing.JTextField();
        type = new javax.swing.JLabel();
        Titre = new javax.swing.JLabel();
        anne_pub = new javax.swing.JLabel();
        edit = new javax.swing.JLabel();
        réference = new javax.swing.JLabel();
        code_is = new javax.swing.JLabel();
        auter = new javax.swing.JLabel();
        auteur = new javax.swing.JTextField();
        code_isbn = new javax.swing.JTextField();
        id_docù = new javax.swing.JLabel();
        id_document = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jToolBar1 = new javax.swing.JToolBar();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        page_connex.setTitle("Connexion");
        page_connex.setSize(450,350);
        page_connex.getContentPane().setLayout(null);

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel4.setText("Nom_Utilisateur :");

        nom_util.setText("admin");

        jLabel5.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel5.setText("Mot de pase: ");

        jButton9.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jButton9.setText("connecter");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(mt_pass)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(nom_util, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(nom_util, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(mt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        page_connex.getContentPane().add(jPanel4);
        jPanel4.setBounds(120, 130, 320, 240);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/client.jpg"))); // NOI18N
        page_connex.getContentPane().add(jLabel14);
        jLabel14.setBounds(0, 0, 564, 501);

        page_connex_s.setTitle("Connexion");
        page_connex_s.setSize(450,350);
        page_connex_s.getContentPane().setLayout(null);

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel7.setText("Nom_Utilisateur :");

        nom_util1.setText("stagiere");
        nom_util1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nom_util1ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel8.setText("Mot de pase: ");

        jButton11.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton11.setText("connecter");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nom_util1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(58, 58, 58))
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mt_pass1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(53, 53, 53))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(70, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nom_util1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(mt_pass1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        page_connex_s.getContentPane().add(jPanel5);
        jPanel5.setBounds(120, 80, 322, 340);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/client.jpg"))); // NOI18N
        page_connex_s.getContentPane().add(jLabel16);
        jLabel16.setBounds(4, 0, 520, 520);

        page_exemplaire.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        page_exemplaire.setTitle("Exemplaire");
        page_exemplaire.setSize(450,400);
        page_exemplaire.getContentPane().setLayout(null);

        jLabel10.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel10.setText("Code_ISBN :");

        jButton6.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jButton6.setText("Ajouter");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "En prete", "En Rayon", "En Réserve", "En Retard", "En travaux", " " }));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jButton10.setText("Retour");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel11.setText("Situation : ");

        jLabel12.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel12.setText("Etat : ");

        jTextField1.setText("neuf");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel13.setText("Id_Document :");

        date.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        date.setText("Date d'achat : ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(date_achat)
                    .addComponent(jTextField1)
                    .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField2)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(id_document_exemp))
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(id_document_exemp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date_achat, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(63, 63, 63))
        );

        page_exemplaire.getContentPane().add(jPanel3);
        jPanel3.setBounds(130, 90, 297, 420);

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/7.jpg"))); // NOI18N
        page_exemplaire.getContentPane().add(jLabel17);
        jLabel17.setBounds(0, 0, 550, 800);

        page_Home_admin1.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        page_Home_admin1.setTitle("Home Administrateur");
        page_Home_admin1.setSize(950,750);
        page_Home_admin1.getContentPane().setLayout(null);

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));

        client3.setColumns(20);
        client3.setRows(5);
        jScrollPane14.setViewportView(client3);

        jLabel33.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText(".:.Bienvenue sur Le Serveur de La Bibliothéque.:.");

        jLabel34.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel34.setText("Liste des Client Connecter :");

        Tab_ret3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_Document", "id_Emprunteur", "Etat", "Date_Retour"
            }
        ));
        Tab_ret3.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane15.setViewportView(Tab_ret3);

        jLabel35.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel35.setText("Table de retour ");

        Tab_emp4.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        Tab_emp4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        Tab_emp4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_Document", "id_Emprunteur", "Date_Emprunt", "Date_Retour"
            }
        ));
        Tab_emp4.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane16.setViewportView(Tab_emp4);

        jLabel36.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel36.setText("Table d'Emprunt ");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel35)
                            .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(250, 250, 250)
                        .addComponent(jLabel34)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel33)
                .addGap(29, 29, 29)
                .addComponent(jLabel34)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(jLabel35))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        page_Home_admin1.getContentPane().add(jPanel9);
        jPanel9.setBounds(70, 60, 836, 567);

        jToolBar3.setRollover(true);

        jButton22.setText("Ajouter Un document");
        jButton22.setFocusable(false);
        jButton22.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton22.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jToolBar3.add(jButton22);

        jButton23.setText("Ajouter Un Exemplaire");
        jButton23.setFocusable(false);
        jButton23.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton23.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        jToolBar3.add(jButton23);

        page_Home_admin1.getContentPane().add(jToolBar3);
        jToolBar3.setBounds(0, 0, 235, 23);

        jButton4.setText("jButton4");
        page_Home_admin1.getContentPane().add(jMenuBar2);

        jMenu3.setText("File");

        jMenuItem5.setText("Connexion Avec Utilisateur");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem5);

        jMenuItem6.setText("Deconnexion");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);

        jMenuBar2.add(jMenu3);

        jMenu5.setText("Edit");

        jMenuItem7.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem7.setText("Ajouter Un document");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem7);

        jMenuItem8.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem8.setText("Ajouter Un Exemplaire");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem8);

        jMenuBar2.add(jMenu5);

        jMenu1.setText("About?");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });
        jMenuBar2.add(jMenu1);

        page_Home_admin1.setJMenuBar(jMenuBar2);

        nouveu_doc.getContentPane().setLayout(null);

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBox1.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Livre", "Mémoire", "Thése", " ", " " }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel8.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 340, 30));
        jPanel8.add(titre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 340, 30));

        anne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                anneActionPerformed(evt);
            }
        });
        jPanel8.add(anne, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 340, 30));
        jPanel8.add(editeur, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 339, 32));
        jPanel8.add(reference, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 340, 30));

        type.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        type.setText("Type :");
        jPanel8.add(type, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 141, -1));

        Titre.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        Titre.setText("Titre :");
        jPanel8.add(Titre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 141, -1));

        anne_pub.setBackground(new java.awt.Color(204, 255, 255));
        anne_pub.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        anne_pub.setText("année de publication :");
        jPanel8.add(anne_pub, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 160, -1));

        edit.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        edit.setText("Editeur :");
        jPanel8.add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 141, -1));

        réference.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        réference.setText("Référence :");
        jPanel8.add(réference, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 141, -1));

        code_is.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        code_is.setText("code_ISBN :");
        jPanel8.add(code_is, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 112, -1));

        auter.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        auter.setText("auteur :");
        jPanel8.add(auter, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 98, 20));

        auteur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                auteurActionPerformed(evt);
            }
        });
        jPanel8.add(auteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 530, 339, 32));
        jPanel8.add(code_isbn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 340, 30));

        id_docù.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        id_docù.setText("id_document :");
        jPanel8.add(id_docù, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 120, 20));
        jPanel8.add(id_document, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 340, 30));

        jButton8.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton8.setText("ajouter un document");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 590, 180, 34));

        jButton17.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton17.setText("Retour ");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 590, 100, 34));

        nouveu_doc.getContentPane().add(jPanel8);
        jPanel8.setBounds(80, 80, 390, 660);

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/7.jpg"))); // NOI18N
        nouveu_doc.getContentPane().add(jLabel26);
        jLabel26.setBounds(0, 0, 550, 820);

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z.jpg"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jToolBar1.setRollover(true);

        jButton2.setText("Connexion Stagiére ");
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton2);

        jButton1.setText("Connexion Admin");
        jButton1.setFocusable(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton1);

        jButton3.setText("About");
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton3);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/What Is Server Hosting_.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        String nom = nom_util.getText();
        String pass = mt_pass.getText();
        try {
            String select = "select *from compte where nom_utilisateur=? and mot_de_pass=?";
            pst = conx.prepareStatement(select);
            pst.setString(1, nom);
            pst.setString(2, pass);
            res = pst.executeQuery();
            if (res.next()) {
                System.out.println("bien connecter");
                page_connex.setVisible(false);
                page_Home_admin1.setVisible(true);
                pst.close();
                res.close();
            } else {
                System.out.println("Non connecter");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.setVisible(false);
        page_connex.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        page_connex_s.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        String nom = nom_util1.getText();
        String pass = mt_pass1.getText();
        try {
            String select = "select *from compte where nom_utilisateur=? and mot_de_pass=?";
            pst = conx.prepareStatement(select);
            pst.setString(1, nom);
            pst.setString(2, pass);
            res = pst.executeQuery();
            if (res.next()) {
                System.out.println("bien connecter");
                Lancer_Thread_Principale();
                page_connex_s.setVisible(false);
                this.setVisible(true);
                pst.close();
                res.close();
            } else {
                System.out.println("Non connecter");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        try {
            String code = jTextField2.getText();
            String situ = (String) jComboBox2.getSelectedItem();
            String id = id_document_exemp.getText();
            String etat = jTextField1.getText();
            String date = date_achat.getText();
            String insert = "INSERT INTO exemplaire(id_document,code_isbn,situ,etat,date_achat)VALUES(?,?,?,?,?)";
            pst = conx.prepareStatement(insert);
            pst.setString(1, id);
            pst.setString(2, code);
            pst.setString(3, situ);
            pst.setString(4, etat);
            pst.setString(5, date);
            pst.execute();
            javax.swing.JOptionPane.showMessageDialog(null, "Vous avez Bien Insérer l'exemplaire");

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "changer votre identificateur ou code_isbn doit etre unique", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);

            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        page_exemplaire.setVisible(false);
        page_Home_admin1.setVisible(true);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        this.setVisible(false);
        nouveu_doc.setVisible(true);
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        page_exemplaire.setVisible(true);
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        Lancer_Thread_Principale();
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        ferme();
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed

    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void nom_util1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nom_util1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nom_util1ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void anneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_anneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_anneActionPerformed

    private void auteurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_auteurActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_auteurActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        try {
            String type = (String) jComboBox1.getSelectedItem();
            String Titre = titre.getText();
            String id = id_document.getText();
            String code = code_isbn.getText();
            String année = anne.getText();
            String edit = editeur.getText();
            String ref = reference.getText();
            String insert = "INSERT INTO document_1 (type,id_document,code_isbn,titre,anne,editeur,reference,auteur)VALUES(?,?,?,?,?,?,?,?)";
            pst = conx.prepareStatement(insert);
            String aut = auteur.getText();
            pst.setString(1, type);
            pst.setString(2, id);
            pst.setString(3, code);
            pst.setString(4, Titre);
            pst.setString(5, année);
            pst.setString(6, edit);
            pst.setString(7, ref);
            pst.setString(8, aut);
            pst.execute();
               javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez Bien Ajouter");
        } catch (Exception ex) {
            ex.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null, "changer votre id ou code ,Réference doit etre unique", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
      page_Home_admin1.setVisible(true);
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        about a = new about();
        a.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed
    about a = new about();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu1ActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
 about a = new about();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Fen_princi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Fen_princi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Fen_princi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Fen_princi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Fen_princi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTable Tab_emp4;
    public static javax.swing.JTable Tab_ret3;
    private javax.swing.JLabel Titre;
    private javax.swing.JTextField anne;
    private javax.swing.JLabel anne_pub;
    private javax.swing.JLabel auter;
    private javax.swing.JTextField auteur;
    public javax.swing.JTextArea client3;
    private javax.swing.JLabel code_is;
    private javax.swing.JTextField code_isbn;
    private javax.swing.JLabel date;
    private javax.swing.JTextField date_achat;
    private javax.swing.JLabel edit;
    private javax.swing.JTextField editeur;
    private javax.swing.JTextField id_document;
    private javax.swing.JTextField id_document_exemp;
    private javax.swing.JLabel id_docù;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    public javax.swing.JButton jButton17;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    public static javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar3;
    private javax.swing.JPasswordField mt_pass;
    private javax.swing.JPasswordField mt_pass1;
    private javax.swing.JTextField nom_util;
    private javax.swing.JTextField nom_util1;
    private javax.swing.JFrame nouveu_doc;
    public static javax.swing.JFrame page_Home_admin1;
    private javax.swing.JFrame page_connex;
    private javax.swing.JFrame page_connex_s;
    private javax.swing.JFrame page_exemplaire;
    private javax.swing.JTextField reference;
    private javax.swing.JLabel réference;
    private javax.swing.JTextField titre;
    private javax.swing.JLabel type;
    // End of variables declaration//GEN-END:variables
}
