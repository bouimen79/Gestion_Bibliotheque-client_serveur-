

import javax.swing.table.DefaultTableModel;


public class Thread_reception extends Thread {

    Fen_Princi Fen_pr;
    Thread_principale Thread_pr;

    // Fen_principale h;
    telecharger t;

    public Thread_reception(Fen_Princi Fen_principale, Thread_principale Thread_principale) {
        Fen_pr = Fen_principale;

        Thread_pr = Thread_principale;

    }
    boolean num = false;

    public void run() {
        try {
            while (true) {
                if (num == false) {
                    String Message_Recu = (String) Thread_pr.Reader.readLine();
                    Thread_pr.indice = Integer.parseInt(Message_Recu);
                    System.out.println("message recu par le serveur" + Message_Recu);
                    num = true;
                    System.out.println("le num boolean " + num);
                } else {
                    try {
                        String Message_Recu = Thread_pr.Reader.readLine();
                        System.out.println("message recu par le serveur" + Message_Recu);
                        String s1[] = Message_Recu.split(",");
                        String ordre = s1[0];
                        System.out.println("l'ordre recu par le serveur" + ordre);
                        switch (ordre) {
                            case "bien connecter": {//message recu la part de serveur si les donne qui envoie par la connexion est correct
                                javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez Bien Connecter");
                                Fen_Princi.page_connx.setVisible(false);

                                telecharger t = new telecharger();
                                t.setVisible(true);

                                break;
                            }
                            case "Erreur d'inscription": {
                                javax.swing.JOptionPane.showMessageDialog(null, "Erreur d'inscription ce id est déja existe?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                break;
                            }
                            case "bien inscrit": {// si les donnes d'inscription est correct 
                                javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez Bien inscrit");
                                Fen_Princi.page_inscri.setVisible(false);

                                Fen_Princi.page_connx.setVisible(true);

                                break;
                            }
                            case "nom_utilisateur existé": {//le cas d'un nom_utlisateur deja existe
                                javax.swing.JOptionPane.showMessageDialog(null, "Erreur d'inscription id_utilisateur déja Existé?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                break;
                            }
                            case "mot de passe modifier": {//si le mor de passe bien modifier
                                javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez Bien modifier votre mot de passe");

                                Fen_Princi.page_oublier.setVisible(false);
                                Fen_Princi.page_connx.setVisible(true);

                                break;
                            }
                            case "Bien inscri nv_emprunteur": {
                                javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez Bien inscrit");
                                Fen_Princi.page_nv_emprunteur.setVisible(false);
                                Fen_Princi.page_chercher_document.setVisible(true);

                                break;
                            }
                               case"donne":{
                                String type=s1[1];String id_document=s1[2];String code_isbn=s1[3];String titre=s1[4];
                                 String table[]={type,id_document,code_isbn,titre};
                                 DefaultTableModel tb=(DefaultTableModel)Fen_Princi.table_document.getModel();
                                 tb.addRow(table);
                                 System.out.println("Thread_reception.run()"+table);
                                 break;
                            }
                            case "ghrama": {
                                javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez une amende forfitére vous avez pas le droit de préter d'autre document");
                                break;
                            }
                            //---------------------------------------------------------Etat de document ------------------------------------------------------------
                            case "Etat": {
                                String etat = s1[1];
                                switch (etat) {

                                    case "En Rayon": {
                                             String id=s1[2];
                                       //  System.out.println("son id est :"+id);
                                       Fen_Princi.id_doc1.setText(id);
                                  
                                        javax.swing.JOptionPane.showMessageDialog(null, "Ce Document est En Rayon vous pouver Emprunter");
                                        Fen_Princi.page_chercher_document.setVisible(false);
                                        
                                        Fen_Princi.page_chercher_client.setVisible(true);
                                        Fen_Princi.id_exemplaire.setText(id);
                                        break;
                                    }
                                    case "En Réserve": {
                                        javax.swing.JOptionPane.showMessageDialog(null, "Ce document est En Réserve vous ne pouvez pas Emprunter ?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                        Fen_Princi.page_emprunt.setVisible(false);
                                        Fen_Princi.page_Home_bib.setVisible(true);

                                        break;
                                    }
                                    case "En travaux": {
                                        javax.swing.JOptionPane.showMessageDialog(null, "Ce document est En travaux vous ne pouvez pas Emprunter");
                                        Fen_Princi.page_Home_bib.setVisible(true);

                                        break;
                                    }
                                    case "En prete": {
                                      javax.swing.JOptionPane.showMessageDialog(null, "Ce document est deja en Prete vous ne pouvez pas Emprunter ?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                        Fen_Princi.page_emprunt.setVisible(false);
                                        Fen_Princi.page_Home_bib.setVisible(true);

                                        break;
                                    }
                                    case "En Retard": {
                                        javax.swing.JOptionPane.showMessageDialog(null, "Attention Vous Avez retourner le Document En Retard?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                        Fen_Princi.page_Home_bib.setVisible(true);
                                        break;
                                    }
                                    default:
                                        javax.swing.JOptionPane.showMessageDialog(null, "Erreur de connexion en case d'etat?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);

                                }
                                break;
                            }
//--------------------------------------------Etat de Client ------------------------------------------------------------------------------                            

                            case "Etat de client": {
                                String etat_client = s1[1];
                                switch (etat_client) {
                                    case "client occasionel": {
                                        String date_emp = s1[2];
                                        String date_ret = s1[3];
                                        javax.swing.JOptionPane.showMessageDialog(null, "Vous etes un Client Occasionel vous avez le droit d'emprunt 1 seul document en 15 jour\n" + "date d'aujorduit(date_emprunt) : " + date_emp + "\n date de retour :" + date_ret);

                                        Fen_Princi.page_chercher_client.setVisible(false);
                                        Fen_Princi.page_emprunt.setVisible(true);
                                        Fen_Princi.jTextField7.setText(date_ret);

                                        break;
                                    }
                                    case "client abonnées": {
                                        String date_emp = s1[2];
                                        String date_ret = s1[3];
                                        javax.swing.JOptionPane.showMessageDialog(null, "Vous etes un Client Abonné vous avez le droit d'emprunt 4 document au plus dans un mois\n" + "date d'aujorduit(date_emprunt) : " + date_emp + "\n date de retour :" + date_ret);

                                        Fen_Princi.page_chercher_client.setVisible(false);
                                        Fen_Princi.page_emprunt.setVisible(true);
                                        Fen_Princi.jTextField7.setText(date_ret);
                                        break;
                                    }
                                    case "client priviligié": {
                                        String date_emp = s1[2];
                                        String date_ret = s1[3];
                                        javax.swing.JOptionPane.showMessageDialog(null, "Vous etes un Client Priviligié vous avez le droit d'emprunt 8 document au plus dans un mois\n" + "date d'aujorduit(date_emprunt) : " + date_emp + "\n date de retour :" + date_ret);

                                        Fen_Princi.page_chercher_client.setVisible(false);
                                        Fen_Princi.page_emprunt.setVisible(true);
                                        Fen_Princi.jTextField7.setText(date_ret);
                                        break;
                                    }
                                    default:
                                        javax.swing.JOptionPane.showMessageDialog(null, "Erreur de connexion en case de etat de client?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);

                                        break;
                                }

                                break;
                            }
                            case "information emprunteur": {
                                try {
                                    String nom = s1[1];
                                    String prenom = s1[2];
                                    String date = s1[3];
                                    System.out.println("Nom" + nom);
                                    System.out.println("Prenom " + prenom);
                                    Fen_Princi.nom1.setText(nom);
                                    Fen_Princi.prenom.setText(prenom);
                                    Fen_Princi.date_naissance.setText(date);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;
                            }
                            case "information document": {
                                try {
                                  
                                    String titre = s1[1];
                                    Fen_Princi.titre.setText(titre);
                                    String anne = s1[2];
                                    Fen_Princi.anne.setText(anne);
                                    String edit = s1[3];
                                   Fen_Princi.editeur.setText(edit);
                                    String ref = s1[4];
                                   Fen_Princi.refer.setText(ref);
                                    String auteur = s1[5];
                                    Fen_Princi.auteur.setText(auteur);
                                    String Type=s1[6];
                                    Fen_Princi.type.setText(Type);
                                    String id_doc = s1[7];
                                Fen_Princi.id_document.setText(id_doc);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    //   javax.swing.JOptionPane.showMessageDialog(null, "Erreur de connexion en case d'etat?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                    javax.swing.JOptionPane.showMessageDialog(null, e);

                                }
                                break;

                            }
                            case "bien emprunter": {
                                javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez Emprunter le Document");
                                Fen_Princi.page_emprunt.setVisible(false);
                                Fen_Princi.page_Home_bib.setVisible(true);

                                break;
                            }
                                        case"Erreur d'emprunt":{
                           javax.swing.JOptionPane.showMessageDialog(null, "Vous n'avez pas le Droite d'emprunter avant de retourner le document!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                           Fen_Princi.page_chercher_client.setVisible(false);
     break;
                            }
                            case "bien Retourner le document": {
                                String etat_retour = s1[1];
                                if (etat_retour.equals("En Retard")) {
                                    javax.swing.JOptionPane.showMessageDialog(null, "Attention Vous Avez retourner le Document En Retard?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                                } else {
                                    javax.swing.JOptionPane.showMessageDialog(null, "Vous Avez bien retourner le Document");
                                    Fen_Princi.page_retourne.setVisible(false);
                                    Fen_Princi.page_Home_bib.setVisible(true);
                                }
                                break;
                            }

                            default:
                                javax.swing.JOptionPane.showMessageDialog(null, "Erreur de connexion en case?!", "wrong pass", javax.swing.JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
        };

    }

}
