import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.JOptionPane;

public class Thread_principale extends Thread {

    int indice;
    Thread_reception Thread_Recept;
    Socket sock;
    InputStream Flux_Entree;
    OutputStream Flux_Sortie;
    BufferedReader Reader;
    PrintWriter Writer;
   Fen_Princi Fen_pr;

    public Thread_principale(Fen_Princi Fen_principale_p) {
        Fen_pr = Fen_principale_p;
    }
    public void run() {
        try {
            Demande_connexion();
            Recuperer_les_flux();
            Dialoguer();
        } catch (Exception e) {

        }
    }
    void Demande_connexion() {
        try {
            System.out.println("demande de connexion");
            sock = new Socket(InetAddress.getByName("127.0.0.1"), 1000);
            System.out.println("ma connexion est accepter");
        } catch (Exception e) {
            System.out.println("erreur dans la demande de la connexion");
        };
    }

    void Recuperer_les_flux() {
        try {
            System.out.println("recuperation des flux de entrer et de sortie");
            Flux_Entree = sock.getInputStream();
            Reader = new BufferedReader(new InputStreamReader(Flux_Entree));
            Flux_Sortie = sock.getOutputStream();
            Writer = new PrintWriter(Flux_Sortie, true);
            System.out.println("Flux d'entree et de sortie recuperer");
        } catch (Exception e) {
            System.out.println("erreur dans la recuperation des flux");
            JOptionPane.showMessageDialog(null, e);
        }
    }

    void Dialoguer() {
        Thread_Recept = new Thread_reception(Fen_pr,this);
        Thread_Recept.start();
    }

    void Fermer_connexion() {
        try {
            Flux_Entree.close();
            Flux_Sortie.close();
            sock.close();
            System.out.println("connexion fermer");
        } catch (Exception e) {
            System.out.println("erreur");
        }
    }
}
